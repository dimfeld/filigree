DELETE FROM report_sections
WHERE organization_id = $1
  AND id = $2
  AND report_id = $3
